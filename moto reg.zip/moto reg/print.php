<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Motorcycle Sticker</title>
    <link rel="stylesheet" href="print.css">
</head>
<body>

    <div class="sticker-container">
        <!-- The plate number will be inserted here from PHP -->
        <div class="plate-number">
            <?php
                // Retrieve the plate number from the URL
                if (isset($_GET['plate-number'])) {
                    echo htmlspecialchars($_GET['plate-number']);
                } else {
                    echo 'No Plate Number Found';
                }
            ?>
        </div>
    </div>

    <button class="print-btn" onclick="window.print()">Print Sticker</button>

</body>
</html>
