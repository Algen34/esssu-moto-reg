// server.js
const express = require('express');
const { Pool } = require('pg'); // PostgreSQL client
const multer = require('multer');
const path = require('path');

const app = express();
const port = 3000; // Using the hard-coded port from your credentials

// Hard-coded PostgreSQL connection credentials
const pool = new Pool({
    user: 'postgres', // Your database username
    host: 'localhost', // Your database host
    database: 'moto-reg_database', // Your database name
    password: 'algen', // Your database password
    port: 5432, // Your database port
});

// Middleware for parsing form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set up multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Serve static files (like your CSS)
app.use(express.static(__dirname)); // Serve static files from the current directory

// Serve the landing page at the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'landing moto reg.html')); // Serve landing moto reg.html
});

// Serve the registration form page
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'fill.html')); // Serve fill.html (registration form)
});

// Serve the print page
app.get('/print', (req, res) => {
    res.sendFile(path.join(__dirname, 'print.html')); // Serve print.html
});

// Serve the print page with the latest plate number
app.get('/print', async (req, res) => {
    try {
        const result = await pool.query('SELECT plate_number FROM motorregistration ORDER BY id DESC LIMIT 1');
        const plateNumber = result.rows.length > 0 ? result.rows[0].plate_number : 'No plate number found';

        // Render the print page with the plate number
        res.render('print', { plateNumber }); // Assuming you're using a template engine like EJS
    } catch (error) {
        console.error('Error fetching plate number:', error);
        res.status(500).send('Error fetching plate number. Please try again.');
    }
});

// Test PostgreSQL connection
pool.connect()
    .then(client => {
        console.log('Connected to PostgreSQL database');
        client.release(); // Release the client back to the pool
    })
    .catch(err => {
        console.error('Error connecting to PostgreSQL database:', err);
    });

// Route to handle form submission
app.post('/add-registration', upload.single('id-image'), async (req, res) => {
    const { name, student_number, plate_number, phone_number } = req.body;
    const id_image = req.file.buffer; // Get the file buffer

    try {
        const query = `
            INSERT INTO motorregistration (name, student_number, plate_number, phone_number, id_image)
            VALUES ($1, $2, $3, $4, $5)
        `;
        const values = [name, student_number, plate_number, phone_number, id_image];

        await pool.query(query, values);
        // Redirect to the print page after successful registration
        res.redirect('/print'); // Redirect to the print page
    } catch (error) {
        console.error('Error inserting data:', error);
        res.status(500).send('Error registering motorcycle. Please try again.');
    }
});

// Route to handle search requests
app.get('/search', async (req, res) => {
    const { name } = req.query;

    try {
        const result = await pool.query('SELECT name, student_number, plate_number, phone_number, id_image FROM motorregistration WHERE name ILIKE $1', [`%${name}%`]);
        
        // Convert id_image to base64
        const resultsWithBase64Images = result.rows.map(row => ({
            ...row,
            id_image: row.id_image ? row.id_image.toString('base64') : null // Convert to base64
        }));

        res.json(resultsWithBase64Images); // Send the results as JSON
    } catch (error) {
        console.error('Error fetching registration:', error);
        res.status(500).send('Error fetching registration. Please try again.');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});